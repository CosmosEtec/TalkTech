<?php
// Classes
require_once dirname(__FILE__)."/../classes/_ExtraProcesses.php";
require_once dirname(__FILE__)."/../classes/Backup.php";
require_once dirname(__FILE__)."/../classes/File.php";
require_once dirname(__FILE__)."/../classes/Settings.php";
require_once dirname(__FILE__)."/../classes/System.php";
require_once dirname(__FILE__)."/../classes/URL.php";

// Headers & Settings
require_once dirname(__FILE__)."/headers.php";
require_once dirname(__FILE__)."/settings.php";
